const input = document.getElementById('terminal-input');
const output = document.getElementById('terminal-output');
const promptSection = document.getElementById('prompt-section');

const DATA = {
    social: [
        { name: 'GitHub', url: 'https://github.com', icon: '󰊤' },
        { name: 'Twitter', url: 'https://twitter.com', icon: '󰕄' },
        { name: 'LinkedIn', url: 'https://linkedin.com', icon: '󰈄' }
    ],
    articles: [
        { title: 'The Future of AI Coding', status: 'Liked', url: '#' },
        { title: 'Understanding CRT Shaders', status: 'To Read', url: '#' }
    ],
    videos: [
        { title: '90s Tech Nostalgia', status: 'Liked', url: '#' },
        { title: 'Hardware Hacking 101', status: 'Watch Later', url: '#' }
    ]
};

const COMMANDS = {
    help: () => `Available commands: 
- <span class="keyword">social</span>: Display social media links
- <span class="keyword">articles</span>: List my articles
- <span class="keyword">videos</span>: List interesting videos
- <span class="keyword">clear</span>: Clear the terminal
- <span class="keyword">whoami</span>: About me`,
    social: () => DATA.social.map(s => `[<span class="url" onclick="window.open('${s.url}')">${s.name}</span>]`).join('  '),
    articles: () => DATA.articles.map(a => `- [${a.status}] <span class="url" onclick="window.open('${a.url}')">${a.title}</span>`).join('\n'),
    videos: () => DATA.videos.map(v => `- [${v.status}] <span class="url" onclick="window.open('${v.url}')">${v.title}</span>`).join('\n'),
    whoami: () => `I'm a programmer with a passion for vintage aesthetics and modern code. Welcome to my digital terminal.`,
    clear: () => {
        const lines = output.querySelectorAll('.command-line, .command-output');
        lines.forEach(line => line.remove());
        return null;
    }
};

async function bootSequence() {
    const lines = [
        "Initializing BIOS...",
        "Memory Check: 640KB OK",
        "Loading Kernel...",
        "Starting Terminal Interface...",
        "Welcome, User. Type 'help' to begin."
    ];

    for (const line of lines) {
        await typeOutput(line, 'command-output', 50);
        await new Promise(r => setTimeout(r, 200));
    }
}

function typeOutput(text, className, speed = 20) {
    return new Promise(resolve => {
        const div = document.createElement('div');
        div.className = className;
        output.insertBefore(div, promptSection);

        let i = 0;
        const interval = setInterval(() => {
            div.innerHTML += text[i];
            i++;
            if (i >= text.length) {
                clearInterval(interval);
                resolve();
            }
            output.scrollTop = output.scrollHeight;
        }, speed);
    });
}

function handleCommand(cmd) {
    const trimmed = cmd.toLowerCase().trim();
    if (!trimmed) return;

    // Echo command
    const echoLine = document.createElement('div');
    echoLine.className = 'command-line';
    echoLine.innerHTML = `<span class="prompt">guest@terminal:~$</span> ${cmd}`;
    output.insertBefore(echoLine, promptSection);

    // Process command
    if (COMMANDS[trimmed]) {
        const result = COMMANDS[trimmed]();
        if (result) {
            const outputLine = document.createElement('div');
            outputLine.className = 'command-output';
            outputLine.innerHTML = result;
            output.insertBefore(outputLine, promptSection);
        }
    } else {
        const errorLine = document.createElement('div');
        errorLine.className = 'command-output error';
        errorLine.innerHTML = `Command not found: ${trimmed}. Type 'help' for available commands.`;
        output.insertBefore(errorLine, promptSection);
    }

    output.scrollTop = output.scrollHeight;
}

input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        const cmd = input.value;
        handleCommand(cmd);
        input.value = '';
    }
});

// Focus terminal on click anywhere
document.addEventListener('click', () => input.focus());

// Start boot sequence
bootSequence();
